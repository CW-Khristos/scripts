=========================================================================================
==                                                                                     ==
== x.Robot 2.0 Usage Document                                                          ==
==                                                                                     ==
== (c) Paul Alan Freshney 2017                                                         ==
==                                                                                     ==
== www.xinorbis.com / www/maximumoctopus.com / xinorbis@maximumoctopus.com             ==
==                                                                                     ==
==                                                                                     ==
==  April 13th 2017                                                                    ==
==                                                                                     ==
=========================================================================================


Please note: you are not permitted to sell this software, or to distribute a modified
version of this archive or application.

This program is provided AS IS, I will not be responsible for any damage to you or your
computer that arise through the use of the software.

If you have any suggestions for improvements or if you find any bugs *please* email me! 

Send feedback to;
  xinorbis@maximumoctopus.com


Thanks!


Paul.
(April 13th 2017)

=========================================================================================
== Version History                                                                     ==
=========================================================================================

2.0 (April 13th 2017)

- Renamed to X.Robot
- Major rewrite
- Lots of fixes, improvements, and tweaks

1.4 (July 12th 2015)

- Added langauge support, now supports the same languages
  as Xinorbis
- Improved all report output
- Fixed a couple of minor bugs

1.3 (January 21st 2015)

~ Now works with the latest versions of the Xinorbis
  database format.
~ Minor updates


1.2.2 (December 10th 2009)

~ Fixed a bug relating to the $DD and $dd parameters

1.2.1 (September 20th 2009)

~ Fixed CSV output.
~ Some other minor tweaks.

1.2 (July 4th 2009)

~ Some bugs fixed. 

1.1 (May 2nd 2009)

~ Added progress information
~ Changes to the internal workings
~ Some bugs fixed.

1.0 (October 16th 2008)

~ First public release.

=========================================================================================
==                                                                                     ==
=========================================================================================